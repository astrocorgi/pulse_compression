%% Creating a basic pulse compression algorithm
%  This script creates a series of plots based on the processing of data
%  from the SHARAD instrument on Mars Reconnaissance Orbiter. First it
%  plots a simple chirped pulse, and then it applies pulse compression and
%  a Hamming window to the signal.
%
%       Created by Cassie Stuurman
%% Plotting a chirped pulse
%  First, I plot a single SHARAD chirp. It is a 85 microsecond long pulse
%  that is linearly modulated with a 20 MHz central frequency and a 10 MHz
%  bandwidth.

close all

T = 85e-6;%pulse length, seconds
L = 5000; %number of points in time vector
Fs = 5000; %define a sampling frequency for Fourier transform later
t = linspace(0,85e-6,L); %time axis, s
f_0 = 20e6; %central frequency, Hz
delta_f = 10e6; %bandwidth of chirp, Hz
A = 1; %assuming normalized amplitude here

f_1 = 15e6; %lowest frequency, Hz
f_2 = 25e6; %highest frequency, Hz
k = (f_2-f_1)/T;

%According to https://en.wikipedia.org/wiki/Pulse_compression, the chirped
%y(t) is:
y = A*exp(2*1i*pi*( (f_0-(delta_f/2)*(T/2-t) + delta_f/(2*T)*(T/2-t).^2))); %from pulse compression page
y_2 = A*exp(2*pi*1i*(f_0*t+(k*t.^2)/2)); %from chirp compression page

%Plotting the simple pulse

plot(t,y,'LineWidth',1);
xlabel('Time, (s)');
ylabel('Amplitude');
title('Single SHARAD chirp, central frequency 20 MHz (pulse)');

figure
plot(t,y_2);
xlabel('Time, (s)');
ylabel('Amplitude');
title('Single SHARAD chirp, central frequency 20 MHz (chirp)');

%% Next we take the Fourier transform of the pulse signal

symmspot = find(f==400);
fourier = fft(y_2,L);
P2 = abs(fourier/max(fourier)); %two-sided spectrum,normalized
P1 = P2(1:L/2);%one-sided spectrum
P1(2:end-1) = P1(2:end-1);
f = Fs*(1:(L/2))/L; %define a frequency domain

%Plotting the results
figure
plot(f,P1);
title('Fourier spectrum of the simple pulse');
ylabel('Amplitude');
xlabel('Frequency (Hz)');
%% Applying a Hamming window

P1 = P1(1:symmspot);
ham = hamming(symmspot)'; %create a hamming window using MATLAB's handy function
hammed_fq = ham.*P1; %the signal with hamming window applied, freq domain

figure
plot(f(1:symmspot),hammed_fq);
hold on
plot(f(1:symmspot),ham)
legend('Fourier Transform with window applied','Hamming window');
title('Hamming Window');
xlabel('Frequency, (Hz)');
ylabel('Amplitude');

%% Converting back to time domain

hammed_time = ifft(hammed_fq); %signal, hamming window applied, time domain
hammed_time = abs(hammed_time/max(hammed_time));
hammed_time = circshift(hammed_time',[length(hammed_time)/2,0]);
figure
plot(t(1:symmspot),hammed_time);
xlabel('Time, (s)');
ylabel('Amplitude');
title('Signal with Hamming Window Applied, time domain');

